import type { NextAuthOptions } from "next-auth";
import { prisma } from "./prisma";
import GoogleProvider from "next-auth/providers/google";

// We add support for logging in with email and password using the built-in
// Credentials provider. The bcryptjs library is used to compare the
// provided password with the hashed password stored in the database.
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";

export const authOptions: NextAuthOptions = {
  secret: process.env.NEXTAUTH_SECRET,
// ✅ aqui (config do NextAuth)
  providers: [
    // Credentials provider for email/password based authentication. The
    // authorize function checks for a matching user in the database and
    // verifies the supplied password against the stored hash using
    // bcryptjs. Returning `null` will cause the sign‑in attempt to
    // fail silently.
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "E-mail", type: "email" },
        password: { label: "Senha", type: "password" },
      },
      async authorize(credentials) {
        const email = (credentials?.email || "").toLowerCase();
        const password = credentials?.password || "";
        if (!email || !password) {
          return null;
        }
        const user = await prisma.user.findUnique({ where: { email } });
        if (!user || !user.password) {
          return null;
        }
        const isValid = await bcrypt.compare(password, user.password);
        if (!isValid) {
          return null;
        }
        // Users whose accounts have been denied cannot sign in.
        if (user.status === "DENIED") {
          return null;
        }
        return {
          id: user.id.toString(),
          name: user.name ?? undefined,
          email: user.email ?? undefined,
          role: user.role,
          status: user.status,
        };
      },
    }),
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      authorization: {
        params: {
          prompt: "consent",
          access_type: "offline",
          response_type: "code",
          scope: [
            "openid",
            "email",
            "profile",
            "https://www.googleapis.com/auth/calendar.readonly",
          ].join(" "),
        },
      },
    }),
  ],
  pages: { signIn: "/login", error: "/login" },
  callbacks: {
    async signIn({ user, account, profile }) {
      // Only run the Google onboarding logic for Google sign‑ins. When
      // the provider is `credentials` we return true here to allow
      // sign‑in to succeed and defer user validation to the
      // Credentials provider's `authorize` method above.
      if (account?.provider !== "google") {
        return true;
      }
      const email = (profile?.email || "").toLowerCase();
      const name = (profile as any)?.name || null;
      if (!email) return false;

      const masterEmail = (process.env.MASTER_EMAIL || "").toLowerCase();

      let user = await prisma.user.findUnique({ where: { email } });

      if (!user) {
        user = await prisma.user.create({
          data: {
            email,
            name,
            status: email === masterEmail ? "ACTIVE" : "PENDING",
            role: email === masterEmail ? "MASTER" : "PROFESSIONAL",
          },
        });

        if (email !== masterEmail) {
          await prisma.accessRequest.create({
            data: { email, name, status: "PENDING", userId: user.id },
          });
        }
      } else {
        if (email === masterEmail && (user.role !== "MASTER" || user.status !== "ACTIVE")) {
          user = await prisma.user.update({
            where: { id: user.id },
            data: { role: "MASTER", status: "ACTIVE" },
          });
        }
      }

      if (email !== masterEmail) {
        const pending = await prisma.accessRequest.findFirst({ where: { email, status: "PENDING" } });
        if (!pending && user.status === "PENDING") {
          await prisma.accessRequest.create({ data: { email, name, status: "PENDING", userId: user.id } });
        }
      }

      return true;
    },

    async jwt({ token, account }) {
      const email = (token.email || "").toString().toLowerCase();

      if (email) {
        const user = await prisma.user.findUnique({ where: { email } });
        if (user) {
          (token as any).role = user.role;
          (token as any).status = user.status;
          (token as any).userId = user.id;
        }
      }

      if (account?.provider === "google" && account.access_token && email) {
        const user = await prisma.user.findUnique({ where: { email } });
        if (user) {
          await prisma.googleCalendarLink.upsert({
            where: { userId: user.id },
            create: {
              userId: user.id,
              accessToken: account.access_token || null,
              refreshToken: (account.refresh_token as any) || null,
              expiryDate: account.expires_at ? new Date(account.expires_at * 1000) : null,
              approved: false,
            },
            update: {
              accessToken: account.access_token || null,
              refreshToken: (account.refresh_token as any) || undefined,
              expiryDate: account.expires_at ? new Date(account.expires_at * 1000) : null,
            },
          });
        }
      }

      return token;
    },

    async session({ session }) {
      const email = (session.user?.email || "").toLowerCase();
      if (!email) return session;

      const user = await prisma.user.findUnique({ where: { email } });
      const link = user
        ? await prisma.googleCalendarLink.findUnique({ where: { userId: user.id } }).catch(() => null)
        : null;

      (session as any).appUser = user
        ? {
            id: user.id,
            status: user.status,
            role: user.role,
            konsistMedicoNome: user.konsistMedicoNome,
            googleCalendar: link
              ? {
                  approved: link.approved,
                  calendarId: link.calendarId,
                  calendarName: link.calendarName,
                  hasRefreshToken: !!link.refreshToken,
                }
              : null,
          }
        : { status: "PENDING", role: "PROFESSIONAL" };

      return session;
    },
  },
};
