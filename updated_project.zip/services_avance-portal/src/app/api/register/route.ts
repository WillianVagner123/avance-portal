import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

/**
 * API route used to create a new user account. This endpoint accepts
 * JSON POST requests with an `email`, `password` and optional `name`.
 * If the email already exists in the database the request fails with
 * HTTP status 409. Otherwise the password is hashed with bcrypt and a
 * new user record is created with a default role of `PROFESSIONAL` and
 * a status of `PENDING`. Use this route to allow users to sign up
 * using their own credentials.
 */
export async function POST(req: NextRequest) {
  try {
    const data = await req.json();
    const { email, password, name } = data ?? {};

    // Basic validation
    if (typeof email !== "string" || !email.includes("@") || typeof password !== "string" || password.length < 6) {
      return NextResponse.json({ error: "Dados inválidos." }, { status: 400 });
    }

    const normalizedEmail = email.toLowerCase();

    // Check if the user already exists
    const existing = await prisma.user.findUnique({ where: { email: normalizedEmail } });
    if (existing) {
      return NextResponse.json({ error: "Usuário já registrado." }, { status: 409 });
    }

    // Hash the password using bcryptjs
    const hashed = await bcrypt.hash(password, 12);

    await prisma.user.create({
      data: {
        email: normalizedEmail,
        name: typeof name === "string" && name.trim() !== "" ? name.trim() : null,
        password: hashed,
        // Default new users to a professional role with a pending status.
        role: "PROFESSIONAL",
        status: "PENDING",
      },
    });

    return NextResponse.json({ success: true }, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Erro interno." }, { status: 500 });
  }
}