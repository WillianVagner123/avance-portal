import { getPrisma } from "./getPrisma";

export const prisma = getPrisma();
