// Augment the NextAuth session type so that our custom properties are
// correctly recognised by TypeScript. Without this augmentation the
// compiler will complain about properties such as `session.appUser` not
// existing on the Session type. See: https://next-auth.js.org/getting-started/typescript#module-augmentation

import NextAuth from "next-auth";
import { UserRole, UserStatus } from "@prisma/client";

declare module "next-auth" {
  /**
   * Returned by `useSession`, `getSession` and received as a prop on the
   * `SessionProvider` React Context. The default Session interface does not
   * include our additional properties. We extend it here so that
   * TypeScript is aware of them.
   */
  interface Session {
    /**
     * Custom application user metadata attached to the session. When a user
     * signs in we embed a small object on the session so our pages can
     * easily access the authenticated user's id, role, status and any
     * related calendar metadata without repeatedly querying the database.
     */
    appUser?: {
      id: string;
      role: UserRole;
      status: UserStatus;
      /**
       * Information about the user's Google Calendar integration. This may
       * be `null` if the user has not linked their calendar.
       */
      googleCalendarLink?: {
        id: string;
        calendarId: string | null;
        calendarName: string | null;
        approved: boolean;
        approvedAt: Date | null;
      } | null;
    };
  }
}

export {};