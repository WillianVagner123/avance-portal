"use client";

import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCredentialsSignIn(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const result = await signIn("credentials", {
        email,
        password,
        redirect: false,
      });
      if (result && result.error) {
        // The credentials provider returns a generic error string. Show a friendly message.
        setError("E-mail ou senha inválidos.");
      } else {
        // Navigate to the dashboard which will in turn redirect to the appropriate calendar.
        router.push("/dashboard");
      }
    } catch (err) {
      console.error(err);
      setError("Não foi possível iniciar a sessão.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Fundo com imagem */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1631248055158-edec7a3c072b?q=80&w=1161&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')",
        }}
      />

      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/90" />

      {/* Card */}
      <div className="relative z-10 w-full max-w-sm rounded-2xl bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl p-8">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/20 text-xl font-bold">
            A
          </div>

          <h1 className="text-2xl font-semibold text-white">Clínica Avance</h1>
          <p className="mt-1 text-sm text-zinc-300">
            Portal interno de profissionais
          </p>
        </div>

        <form className="space-y-4" onSubmit={handleCredentialsSignIn}>
          <div className="space-y-2">
            <input
              type="email"
              className="w-full rounded-xl bg-white/80 px-4 py-3 text-sm text-zinc-900 placeholder-zinc-500 focus:outline-none"
              placeholder="Seu e-mail"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
              required
            />
            <input
              type="password"
              className="w-full rounded-xl bg-white/80 px-4 py-3 text-sm text-zinc-900 placeholder-zinc-500 focus:outline-none"
              placeholder="Sua senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading}
              required
            />
          </div>
          {error && (
            <p className="text-sm text-red-500 text-center">{error}</p>
          )}
          <button
            type="submit"
            className="w-full rounded-xl bg-blue-600 text-white px-4 py-3 text-sm font-medium hover:bg-blue-700 transition disabled:opacity-50"
            disabled={loading}
          >
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>
        <div className="my-4 flex items-center justify-center">
          <span className="text-xs text-zinc-400">ou</span>
        </div>
        <button
          onClick={() => signIn("google", { callbackUrl: "/dashboard" })}
          className="w-full rounded-xl bg-white text-zinc-900 px-4 py-3 text-sm font-medium hover:bg-zinc-200 transition"
          disabled={loading}
        >
          Entrar com Google
        </button>
        <p className="mt-4 text-center text-xs text-zinc-400">
          Acesso restrito a profissionais autorizados
        </p>
      </div>
    </main>
  );
}