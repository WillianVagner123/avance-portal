export const runtime = "nodejs";
import PickerClient from "./ui";
export default function PickerPage() { return <PickerClient />; }
