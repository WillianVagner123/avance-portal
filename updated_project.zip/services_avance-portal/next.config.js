/** @type {import('next').NextConfig} */
const nextConfig = {
  allowedDevOrigins: ["https://avance-portal-760280164025.southamerica-east1.run.app", "https://avance-portal-760280164025.southamerica-east1.run.app"],
};

module.exports = nextConfig;
